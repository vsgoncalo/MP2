#!/bin/sh
python solucao.py $1 $2